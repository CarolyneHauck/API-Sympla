﻿using System;
namespace consumeEventick.Controllers
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
